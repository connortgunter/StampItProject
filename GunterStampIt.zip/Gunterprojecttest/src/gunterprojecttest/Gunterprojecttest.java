/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gunterprojecttest;

import acm.graphics.*;
import acm.program.*; 
import java.awt.*; 
import java.awt.event.*; 
import java.util.*;

/**
 *
 * @author ConnorGunter
 */
public class Gunterprojecttest extends GraphicsProgram {
    final int WIDTH = 600;
    final int HEIGHT = 600;
    final int LABEL_VERTICAL_POSITION = 20;
    final int DOT_WIDTH = 15;
    final int OFFSET = DOT_WIDTH/2;
    int currentX, currentY, previousX, previousY;
    int dots = 0;
    double totalLength = 0;
    
    final String TITLE = "Gunter Project One";
    final String LABEL = "CLICK ANYWHERE";
    final String FONT = "Arial-24";
    Random rndm = new Random();
    
  
    public static void main(String[] args) {
        new Gunterprojecttest().start();
        // TODO code application logic here
    }
    public void init(){
        setTitle(TITLE);
        setSize(WIDTH,HEIGHT);
        GLabel myLabel = new GLabel (LABEL);
        myLabel.setFont(FONT);
        myLabel.setLocation(WIDTH/2-myLabel.getWidth()/2, LABEL_VERTICAL_POSITION);
        add(myLabel);
        
        addMouseListeners();
    }
    public void mouseClicked(MouseEvent me){
        currentX = me.getX();
        currentY = me.getY();
        
        int pick =rndm.nextInt(4);
        Color myColor;
        switch (pick) {
            case 0 : myColor = Color.RED; break;
            case 1 : myColor = Color.BLUE; break;
            case 2 : myColor = Color.MAGENTA; break;
            case 3 : myColor = Color.YELLOW; break;
            case 4 : myColor = Color.lightGray; break;
            default: myColor = Color.black;
        }
        GOval myOval = new GOval(currentX-OFFSET,currentY-OFFSET,DOT_WIDTH,DOT_WIDTH);
        myOval.setFillColor(myColor);
        myOval.setFilled(true);
        add(myOval);
        
        if (dots>0){
            GLine line = new GLine (currentX,currentY,previousX,previousY);
            add(line);
            
            double aSquared = Math.pow (currentX-previousX,2);
            double bSquared = Math.pow (currentY-previousY,2);
            totalLength += Math.sqrt(aSquared+bSquared);
        }
        dots++;
        
        previousX = currentX;
        previousY = currentY;
        
        String dotString = dots == 1 ? "dot," : "dots,";
        
        System.out.printf("%2d %5s total line length = %8.2f\n", dots,dotString,totalLength);
        // use random to pick number 0 to 3
        // myColor = Color.RED;
        // create the dot
        // if the dot count is > 0
        // GLine newLine = new GLine (currentX, currentY,previousX, previousY);
        // add(newLine);
        // calc length to new line
        // length = squareroot of (currentX - previousX) squared + (current Y-
        // previousY) squared
        // add length of new line to total of all lines
        // increase dot count by 1
        // previousX - currentX
        // previousY - currentY
        // printf number of dots and total line length "%4s%10.2f"
        
        
        
        
        
        
        
    }  
           
    }

    
            
    

